# tasks/task4.py

def solve():
# Ниже пишите решение задачи
    
n = int(input())
result = n + 2 - (n % 2)
print(result)

# Код ниже не трогать! он нужен для тестов
if __name__ == "__main__":
    solve()